<?php
// Simple JWT helper for PHP
// Change JWT_SECRET to a secure random string before deploying.
define('JWT_SECRET', 'safar_db_super_secret_key_change_this');

function base64url_encode(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode(string $data): string
{
    $remainder = strlen($data) % 4;
    if ($remainder) {
        $data .= str_repeat('=', 4 - $remainder);
    }
    return base64_decode(strtr($data, '-_', '+/'));
}

function generate_jwt(array $payload, string $secret = JWT_SECRET): string
{
    $header = ['alg' => 'HS256', 'typ' => 'JWT'];
    $segments = [
        base64url_encode(json_encode($header)),
        base64url_encode(json_encode($payload)),
    ];

    $signature = hash_hmac('sha256', implode('.', $segments), $secret, true);
    $segments[] = base64url_encode($signature);
    return implode('.', $segments);
}

function validate_jwt(string $token, string $secret = JWT_SECRET)
{
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return false;
    }

    [$header64, $payload64, $signature64] = $parts;
    $signature = base64url_decode($signature64);
    $expectedSignature = hash_hmac('sha256', "$header64.$payload64", $secret, true);

    if (!hash_equals($expectedSignature, $signature)) {
        return false;
    }

    $payload = json_decode(base64url_decode($payload64), true);
    if (!$payload) {
        return false;
    }

    if (isset($payload['exp']) && time() > $payload['exp']) {
        return false;
    }

    return $payload;
}
