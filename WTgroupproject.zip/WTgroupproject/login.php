<?php
session_start();
include 'db.php';
include 'jwt.php';

$message = "";
$response = ['status' => 'error', 'message' => 'Invalid request'];
$isJson = isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false;

function send_json($payload)
{
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['register'])) {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$name || !$email || !$password) {
            $response = ['status' => 'error', 'message' => 'Please complete the registration form.'];
        } else {
            $checkStmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
            $checkStmt->bind_param('s', $email);
            $checkStmt->execute();
            $checkStmt->store_result();

            if ($checkStmt->num_rows > 0) {
                $response = ['status' => 'error', 'message' => 'Email already exists.'];
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $insertStmt = $conn->prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)');
                $insertStmt->bind_param('sss', $name, $email, $hashedPassword);

                if ($insertStmt->execute()) {
                    $response = ['status' => 'success', 'message' => 'Registration successful! Please login.'];
                } else {
                    $response = ['status' => 'error', 'message' => 'Registration failed: ' . $insertStmt->error];
                }
            }
        }
    } elseif (isset($_POST['login'])) {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$email || !$password) {
            $response = ['status' => 'error', 'message' => 'Please enter your email and password.'];
        } else {
            $stmt = $conn->prepare('SELECT id, name, email, password FROM users WHERE email = ?');
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();

                if (password_verify($password, $user['password'])) {
                    $payload = [
                        'sub' => $user['id'],
                        'name' => $user['name'],
                        'email' => $user['email'],
                        'iat' => time(),
                        'exp' => time() + 86400,
                    ];
                    $token = generate_jwt($payload);
                    setcookie('safar_jwt', $token, time() + 86400, '/');

                    $response = [
                        'status' => 'success',
                        'message' => 'Login successful. Redirecting...',
                        'token' => $token,
                        'redirect' => 'booking.html',
                    ];

                    if (!$isJson) {
                        header('Location: booking.html');
                        exit;
                    }
                } else {
                    $response = ['status' => 'error', 'message' => 'Invalid password.'];
                }
            } else {
                $response = ['status' => 'error', 'message' => 'No account found with that email.'];
            }
        }
    }

    if ($isJson) {
        send_json($response);
    }
    $message = $response['message'];
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SAFAR - Authenticate</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"/>
    <style>
        :root { --primary: #0ea5e9; --dark: #1e293b; --light: #f8fafc; --slate: #64748b; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: "Segoe UI", sans-serif; }
        body { background: var(--light); min-height: 100vh; display: flex; flex-direction: column; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 5%; background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .logo { font-size: 26px; color: var(--primary); text-decoration: none; font-weight: 800; display: flex; align-items: center; gap: 10px; }
        .auth-wrapper { flex: 1; display: flex; justify-content: center; align-items: center; padding: 40px 20px; background: linear-gradient(rgba(30,41,59,0.6), rgba(30,41,59,0.6)), url("https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=2070"); background-size: cover; background-position: center; }
        .auth-container { background: white; padding: 45px; border-radius: 20px; width: 100%; max-width: 420px; text-align: center; }
        .alert { background: #f0fdf4; color: #166534; padding: 12px; border-radius: 10px; margin-bottom: 18px; font-size: 14px; display: none; }
        .input-group { position: relative; margin-bottom: 20px; }
        .input-group i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: var(--primary); }
        .input-group input { width: 100%; padding: 14px 15px 14px 45px; border: 1px solid #e2e8f0; border-radius: 10px; outline: none; background: var(--light); }
        .btn { width: 100%; padding: 14px; background: var(--primary); color: white; border: none; border-radius: 10px; font-weight: 600; cursor: pointer; }
        .toggle-text { margin-top: 25px; font-size: 14px; color: var(--slate); }
        .toggle-text span { color: var(--primary); cursor: pointer; font-weight: 600; }
        .hidden { display: none; }
    </style>
</head>
<body>

<nav class="navbar">
    <a href="index.html" class="logo"><i class="fa-solid fa-paper-plane"></i> SAFAR</a>
</nav>

<div class="auth-wrapper">
    <div class="auth-container">
        <div id="alertBox" class="alert" style="display: <?php echo $message ? 'block' : 'none'; ?>;">
            <?php echo htmlspecialchars($message); ?>
        </div>

        <div id="login-form">
            <h2>Welcome Back</h2>
            <p style="margin-bottom:20px; color:var(--slate)">Sign in to continue your journey.</p>
            <form id="loginForm" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <input type="hidden" name="login" value="1" />
                <div class="input-group">
                    <i class="fa-solid fa-envelope"></i>
                    <input type="email" name="email" placeholder="Email Address" required />
                </div>
                <div class="input-group">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="password" placeholder="Password" required />
                </div>
                <button type="submit" class="btn">Sign In</button>
            </form>
            <div class="toggle-text">New to SAFAR? <span onclick="toggleAuth()">Create Account</span></div>
        </div>

        <div id="register-form" class="hidden">
            <h2>Create Account</h2>
            <p style="margin-bottom:20px; color:var(--slate)">Join SAFAR and start exploring.</p>
            <form id="registerForm" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <input type="hidden" name="register" value="1" />
                <div class="input-group">
                    <i class="fa-solid fa-user"></i>
                    <input type="text" name="name" placeholder="Full Name" required />
                </div>
                <div class="input-group">
                    <i class="fa-solid fa-envelope"></i>
                    <input type="email" name="email" placeholder="Email Address" required />
                </div>
                <div class="input-group">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="password" placeholder="Create Password" required />
                </div>
                <button type="submit" class="btn">Register</button>
            </form>
            <div class="toggle-text">Already have an account? <span onclick="toggleAuth()">Login Here</span></div>
        </div>

    </div>
</div>

<script>
    const alertBox = document.getElementById('alertBox');

    function showAlert(message, isError = false) {
        alertBox.style.display = 'block';
        alertBox.innerText = message;
        alertBox.style.background = isError ? '#fee2e2' : '#f0fdf4';
        alertBox.style.color = isError ? '#991b1b' : '#166534';
    }

    function toggleAuth() {
        document.getElementById('login-form').classList.toggle('hidden');
        document.getElementById('register-form').classList.toggle('hidden');
    }

    async function handleAuth(event) {
        event.preventDefault();
        const form = event.target;
        const data = new FormData(form);

        try {
            const response = await fetch('login.php', {
                method: 'POST',
                headers: { Accept: 'application/json' },
                body: data,
                credentials: 'include',
            });
            const json = await response.json();

            if (json.status === 'success') {
                if (json.token) {
                    localStorage.setItem('safar_jwt', json.token);
                }
                showAlert(json.message, false);
                if (json.redirect) {
                    setTimeout(() => {
                        window.location.href = json.redirect;
                    }, 1100);
                }
                if (form.id === 'registerForm') {
                    setTimeout(() => {
                        toggleAuth();
                    }, 1100);
                }
            } else {
                showAlert(json.message, true);
            }
        } catch (error) {
            showAlert('Unable to contact server. Please try again.', true);
        }
    }

    document.getElementById('loginForm').addEventListener('submit', handleAuth);
    document.getElementById('registerForm').addEventListener('submit', handleAuth);
</script>

</body>
</html>