<?php
setcookie('safar_jwt', '', time() - 3600, '/');
header('Location: login.html');
exit;
