<?php
include 'db.php';
include 'jwt.php';

$token = $_COOKIE['safar_jwt'] ?? '';
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
if (!$token && stripos($authHeader, 'Bearer ') === 0) {
    $token = trim(substr($authHeader, 7));
}
$user = $token ? validate_jwt($token) : false;

function send_json($payload)
{
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

if (!$user) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        http_response_code(401);
        send_json(['status' => 'error', 'message' => 'Unauthorized. Please login first.']);
    }
    header('Location: login.html');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $tour = trim($_POST['tour'] ?? '');
    $days = intval($_POST['days'] ?? 0);
    $travelers = intval($_POST['travelers'] ?? 0);
    $booking_date = trim($_POST['booking_date'] ?? '');
    $booking_time = trim($_POST['booking_time'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $payment_method = trim($_POST['payment'] ?? '');
    $amount = floatval($_POST['amount'] ?? 0);

    if (!$name || !$email || !$phone || !$tour || !$days || !$travelers || !$booking_date || !$booking_time || !$payment_method || $amount <= 0) {
        http_response_code(422);
        send_json(['status' => 'error', 'message' => 'Please fill in all required booking fields.']);
    }

    $stmt = $conn->prepare("INSERT INTO bookings (user_id, name, email, phone, tour, days, travelers, booking_date, booking_time, notes, payment_method, amount, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', NOW())");
    if (!$stmt) {
        http_response_code(500);
        send_json(['status' => 'error', 'message' => 'Database error: ' . $conn->error]);
    }

    $userId = intval($user['sub']);
    $stmt->bind_param('isssiisssssd', $userId, $name, $email, $phone, $tour, $days, $travelers, $booking_date, $booking_time, $notes, $payment_method, $amount);

    if ($stmt->execute()) {
        send_json(['status' => 'success', 'message' => 'Booking confirmed. Thank you, ' . htmlspecialchars($name) . '!']);
    }

    http_response_code(500);
    send_json(['status' => 'error', 'message' => 'Unable to complete booking: ' . $stmt->error]);
}

http_response_code(405);
send_json(['status' => 'error', 'message' => 'Method not allowed.']);
